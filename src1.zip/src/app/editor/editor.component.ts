import { Component, OnInit, ViewChild } from '@angular/core';
import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';
import { CommonService } from '../services/common.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';

declare var $: any;
@Component({
    selector: 'app-editor',
    templateUrl: './editor.component.html',
    styleUrls: ['./editor.component.scss']
})
export class EditorComponent implements OnInit {
    public Editor = DecoupledEditor;
    myEditor: any;
    public model = {
        editorData: '<p>Hello, world!</p>'
    };
    elementId: string;
    data: string;
    display = false;
    display1 = false;
    display2 = false;
    editor = false;
    USTemplateCopy: any = {};
    JapanTemplateCopy: any = {};
    USTemplate: any = {};
    JapanTemplate: any = {};
    IndiaTemplate: any = {};
    IndiaTemplateCopy: any = {};
    invoicedata: any = {};
    address = '';
    clientContact = '';
    indAddress = '';
    headerstyle: any;
    footerStyle: any;
    contentStyle: string;
    heading: any;
    modifiedInvoice: any = {};
    originalInvoice: any = {};
    saveObject: any = {};
    invoiceObject: any = {};
    japanHtmlObject: any = {};
    indiaHtmlObject: any = {};
    USHtmlObject: any = {};
    showAppendix = false;
    constructor(private common: CommonService) { }

    callInvoiceData(data: {}) {
        this.getInvoiceData(data);
    }

    ngOnInit() {
        this.headerstyle = `<!DOCTYPE html>
    <html>
        <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <style>body {font-size: 16px; color: #333;background-color: #fff;font-family: Verdana !important;}
            body .ui-widget {font-family: Verdana !important;}
            body .ui-widget-content p {font-size: 16px;}
            body p {margin:0;line-height:1.5;}
            table{border-collapse: collapse;background: #fff; width:100%; margin: 0px;}
            .logo-img{width: auto; margin: auto;margin-bottom: 20px;}
            .header-left{width: 50%;padding-left: 40px;font-size: 15px;line-height: 2;font-weight: 500;margin: 0;text-align: left;}
            .header-left label{font-size: 26px; font-weight: 500}
            .header-right{width:10%; text-align:right; display:table-cell;}
            .header-right-label {margin-right: 40px;float: right;}
            .header-right p, .header-right-label p{font-weight: bold;}
            .header-center {font-size: 22px;font-weight: 500;}
            header div table tbody tr{background: #c5d3e5}
    </style>
    </head>
    <body>
    [[HeaderContent]]
    </body>
    </html>`;

        this.footerStyle = `<!DOCTYPE html>
    <html>
        <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <style>body {font-size: 16px; color: #333;background-color: #fff;font-family: Verdana !important;}
            body .ui-widget {font-family: Verdana !important;}
            body .ui-widget-content p {font-size: 16px;}
            body p {margin:0;line-height:1.5;}
            table{border-collapse: collapse;background: #fff; width:100%; margin: 0px;}
            .footer-table{background: #c5d3e5;text-align: center;font-size: 15px;line-height: 24px;}
            .footer-table a{text-decoration: none;color: blue;}
            footer table:first-child{margin-top:10px}
            footer table:first-child tr td{font-size: 14px;text-align: center;}</style>
    </head>
    <body>
    [[FooterContent]]
    </body>
    </html>`;

        this.contentStyle = `<!DOCTYPE html>
    <html>
        <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <style>body {font-size: 16px; color: #333;background-color: #fff;font-family: Verdana !important;}
            table{border-collapse: collapse;background: #fff; width:100%; margin: 0px;}
            body p {margin:0;line-height:1.5;}
            .table-heading{width: 100%;  text-align: center;font-weight: bold;background: #d8d8d8; font-size: 16px;
            color: #000; padding: 10px;}
            .contact_details_japan{height:60px;}
            .contact_details p,.contact_details_japan p{padding-top: 3px;padding-bottom: 3px;}
            .contact_details-table table:first-child{width: 47%;float: left;margin-bottom: 20px;}
            .contact_details-table table:nth-child(2){float: right;text-align: left;width: 44%;display: grid}
            .contact_details-table figure:nth-child(3) table{width: 100%;}
            .referenceDetail figure,.appendix figure,.contact_details-table figure,figure{display: contents;}
            .contact_details-table table:first-child p{margin: 0;line-height: 24px;font-size: 16px;}
            .contact_details-table table:first-child tr td{margin: 0;line-height: 24px;font-size: 16px;}
            p span{display: inline-flex;}
            .contact-detail-table-left {/* padding-left: 30px; */width: 50%;float: left;margin-bottom: 20px;}
            .contact-detail-table-left p,
            .contact-detail-table-right p {margin: 0;line-height: 24px;font-size: 15px;}
            .contact-detail-table-right {float: right;text-align: left;width: 50%;}
            .purchaseOrder p{height:25px;font-size: 16px;}
            .referenceDetail {height: 50px; font-size: 16px;}
            .referenceDetail table {width: 94%;}
            .contact-detail-table{padding-left: 30px;}
            .contact-detail-table p{margin: 0;line-height: 24px;font-size: 16px;}
            ul{line-height: 26px;padding-left:20px;list-style: unset;}
            .paymentDetails,.column-flex{display: inline-flex;}
            .paymentDetails ul{padding-left: 10px;}
            .invoice-table{border-collapse: collapse;width: 100%;}
            .invoice-table table {width: 100%};
            .invoice-table td{border:1px solid #000;padding: 0}
            .invoice-table th{border:1px solid #000;padding: 0}
            .invoice-table table thead tr{text-align: center; font-size: 16px; font-weight: bold;}
            .invoice-table table thead tr th{padding: 10px 12px;}
            .invoice-table table tbody tr td{text-align: center;font-size: 16px;padding: 15px 0;border:1px solid #000;}
            .invoice-table table tfoot tr td{text-align: center;font-size: 16px;padding: 15px 0;font-weight: bold;}
            .invoice-table table tbody tr:last-child td:last-child{font-weight: bold;}
            .invoice-table table tbody tr td:last-child{font-weight: bold;width: 14%;}
            .appendix table tbody tr:last-child td{font-weight: normal;}
            .appendix table tbody tr td:last-child{font-weight: bold;}
            .signature-table{float: right;text-align: right;margin-right: 10px;
            background-image: url(https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EZNP0M5U1nFCgVaguRgo4S0B3-L67nYrXIgtxcYoJEba9w);
             background-repeat: no-repeat;background-position: right;}
            .signature-table p{margin:0;line-height: 24px;}
            .paymentInstructions label {font-size: 16px;font-weight: bold;display: table;margin-top: 20px;}
            .col3{}
            .col4{}
            .col6{}
            .col10 figure table tr:first-child td{font-weight: bold;}
            .col10 figure table tr:first-child td:first-child{width:5%;}
            .col10 figure table tr:first-child td:nth-child(2){width:13%;}
            .col10 figure table tr:first-child td:nth-child(3){width:8%;}
            .col10 figure table tr:first-child td:nth-child(4){width:10%;}
            .col10 figure table tr:first-child td:nth-child(5){width:12%;}
            .col10 figure table tr:first-child td:nth-child(6){width:10%;}
            .col10 figure table tr:first-child td:nth-child(7){width:9%;}
            .col10 figure table tr:first-child td:nth-child(8){width:11%;}
            .col10 figure table tr:first-child td:nth-child(9){width:9%;}
            .col10 figure table tr:first-child td:nth-child(10){width:13%;}
            .proformaDetail table tbody tr:first-child td:nth-child(2){text-align: left;padding: 16px 10px;}
        </style>
    </head>
    <body>
    `;
        this.invoicedata = {
            invoice: 'PROFORMA',
            invoice_no: 'ASZ01-0519-0317',
            invoice_date: 'May 15, 2019',
            usCurrencyName: 'USD',
            usCurrencySymbol: '$',
            JpnCurrencyName: 'JPY',
            JpnCurrencySymbol: '¥',
            IndCurrencyName: 'INR',
            IndCurrencySymbol: 'Rs',
            email: 'gordon.strachan@asstraZeneca.com',
            company: 'AstraZeneca UK Ltd',
            clientcontact1: 'Strachan , Gordon',
            clientcontact2: 'Global Publications Lead - Oncology',
            address1: '', // 'PO Box 30 , Slik Road Business Park',
            address2: '', // 'Macclesfield , GB , SK10 2NA',
            address3: '', // 'United Kingdom',
            address4: '', // 'United Kingdom',
            phone: '+44 (0) 16255170000',
            designation: 'Medical Editorial Reviewer',
            purchaseOrderNumber: '8300324481',
            Appendix: ['150833' , 'ASZ01-MSS-193242', 'MOFFITT Resubmission 2', '4,125.00'],
            centralTax : '39,564.45',
            stateTax : '19,782.22',
            consumptionTax : '43,200.00',
            serviceDetails : 'April Invoice for PO #8300324481 (5 Manuscripts and 1 Poster)',
            invoiceFees : '30,687.50',
            total : '30,687.50'
            // email1: 'gordon.strachan@asstraZeneca.com',
            // company1: 'Novartis',
            // clientcontact: 'Lakshmanan Kamuthurai',
            // indaddress1: '', // 'Novartis Healthcare Private Limited',
            // indaddress2: '', // 'Medical Communications, SSP Oncology Product Lifecycle Services',
            // indaddress3: '', // 'Novartis Business Services, Salarpuria-Sattva',
            // indaddress4: '', // 'Knowledge City Raidurgam, Hyderabad - 500032. Telangana, India.',
            // indaddress5: '',
            // indaddress6: '',
            // indphone: '91 9177833433',
            // dvCode: '', // 150833,
            // cactusSPCode: '', // ASZ01-MSS-193242
            // projectTitle: '', // MOFFITT Resubmission 2
            // Amount: '', // 4,125.00
            // total_US: '', // 4,125.00
            // projectCode_japan: 'SAA02-DEK-193955',
            // title: 'EXPLORE-J STUDY: FH diagnosis slide deck first draft delivered',
            // Amount1: '540,000.00',
            // projectCode_ind: 'NVT02-OTH-200156',
            // title1: 'Sandoz pubscan',
            // clientPoc: 'Lakshmana n Kamuthurai',
            // Amount2: '9,250.00',
        };
        this.USTemplate = {
            headerCreate: `<header id=header>
        <div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background-color: #c5d3e5;">
        <td class="header-left">
        Proforma No : &nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
          Proforma Date : [[InvoiceDate]] <br />
          Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]]) <br />
          <label>[[Invoice]]</label>
        </td>
        <td class="header-right">
          <span>
              <img class="logo-img"
              src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
          </span>
        </td>
        </tr>
            </tbody>
        </table>
        </div>
        </header>`,
            footerCreate: ` <footer id="footer">
        <div>
            <table style="margin-top:10px;">
                <tr>
                    <td style="font-size: 14px;text-align: center;">
                        This is a computer generated proforma and does not require any signature
                    </td>
                </tr>
            </table>
            <table class="footer-table">
        <tr>
          <td>
            Cactus Communications Inc.
          </td>
        </tr>
        <tr>
          <td>214 Carnegie Center, Suite 102, Princeton, NJ 08540, USA</td>
        </tr>
        <tr>
          <td>T: +1(267)-332-0051 F: +1(267) 332-0052</td>
        </tr>
        <tr>
          <td>
            <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
          </td>
        </tr>
        </table>
        </div>
        </footer>`,
            maincontent: `    <div id="main_content">
        <div style='height:1300px;'>
        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">
                        CONTACT DETAILS</td>
                </tr>
            </tbody>
        </table>
        <div class="contact_details-table">
            <div id="contact_details">
                <table>
                <tbody>
                <tr>
                    <td>
                        <p><strong>Company : </strong>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Company]]</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p><strong>Client Contact : </strong>&nbsp;&nbsp;[[ClientContact1]]</p>
                        [[ClientContact]]
                    </td>
                </tr>
                <tr>
                    <td>
                        <p><strong>Email : </strong>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">[[Email]]</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p><strong>Phone : </strong>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Phone]]
                        </p>
                    </td>
                </tr>
                </tbody>
                </table>
                <table style="width:44%;">
                <tbody>
                <tr>
                    <td>
                        <p><strong>Address : </strong>&nbsp;&nbsp;[[Address1]]</p>
                        [[AddressMulti]]
                    </td>
                </tr>
                </tbody>
                </table>
            </div>
        </div>
        <table style="margin: 15px 0">
        <tbody>
            <tr>
                <td class="table-heading">
                    PURCHASE ORDER DETAIL</td>
            </tr>
        </tbody>
        </table>
        <p id="purchaseOrder" class="purchaseOrder">
            <tr>
                <td>
                    <p>
                        <strong>Purchase Order number : </strong>[[PurchaseOrderNumber]]
                    </p>
                </td>
            </tr>
        </p>
        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">
                        PROFORMA DETAIL
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="invoice-table proformaDetail">

        <div id="invoiceDetail" style="margin-bottom: 20px;">
            <table border="0" cellspacing="0" cellpadding="0">
            <thead>
            <tr>
                <th>
                    Date
                </th>
                <th>
                    Service Details
                </th>
                <th>
                    Fees
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    [[InvoiceDate]]
                </td>
                <td>
                    [[InvoiceServiceDetails]]
                </td>
                <td>
                    [[CurrencySymbol]] [[InvoiceFees]]<span>*</span>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    Total
                </td>
                <td>
                    [[CurrencySymbol]] [[Total]]
                </td>
            </tr>
        </tbody>
            </table>
            <p style="font-size: 15px;font-weight: 600;">* Please refer to Appendix 1 for additional details</p>
        </div>
        </div>
        <tbody>
            <tr>
                <td>
                    <label style="font-size: 18px;font-weight: bold;margin-left: 0;">
                        PAYMENT INSTRUCTIONS
                    </label>
                </td>
            </tr>
        </tbody>
        <tbody>
            <tr>
                <td style="font-size:14px">
                    <div id="paymentInstructions">
                    <ul>
                    <li>Please make your payment within 75 days of receiving this proforma. For any questions
                        regarding your
                        account<br />
                        contact <a href="#">payments@cactusglobal.com</a></li>
                    </ul>
                    </div>
                    <div>
                    <ul>
                    <li>
                        <strong>Payment by bank transfer:</strong><br />
                        Bank name: Citibank NA, 785 Fifth Avenue, New York, NY 10022<br />
                        Account #: 9943387205<br />
                        Account name: Cactus Communications Inc.<br />
                        ABA/Routing #: 021 0000 89<br />
                        Purpose: Payment for Invoice – [[InvoiceNumber]]<br />
                        Recipient Address: 2 Neshaminy Interplex, Suite 100, Trevose, PA 19053<br />
                        Recipient Phone: 267-332-0051
                    </li>
                    </ul>
                    </div>
                </td>
            </tr>
        </tbody>
        </div>
        [[APPENDIX]]
        </div>`,
        appendixCreate: `<table style="margin: 15px 0">
        <tbody>
            <tr>
                <td class="table-heading">
                    APPENDIX 1</td>
            </tr>
        </tbody>
        </table>
        <div class="invoice-table">
        <div id="appendix">
        <figure>
        <table>
            <thead>
                <tr>
                    <th>
                        DV code
                    </th>
                    <th>
                        Cactus SP Code
                    </th>
                    <th>
                        Project title
                    </th>
                    <th>
                        Amount
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        [[DvCode]]
                    </td>
                    <td>
                        [[CactusSpCode]]
                    </td>
                    <td>
                        [[ProjectTitle]]
                    </td>
                    <td>
                        [[CurrencySymbol]] [[Amount]]
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        Total
                    </td>
                    <td>
                        [[CurrencySymbol]] [[Total]]
                    </td>
                </tr>
            </tbody>
        </table>
        </figure>
        </div>
        </div>`,
        header: `<div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background-color: #c5d3e5;">
        <td class="header-left">
        Proforma No : &nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
        Proforma Date : [[InvoiceDate]] <br />
          Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]]) <br />
          <label>[[Invoice]]</label>
      </td>
      <td class="header-right">
          <span>
              <img class="logo-img"
               src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
          </span>
      </td>
      </tr>
            </tbody>
        </table>
    </div>`,
            footer: `<div>
        <table style="margin-top:10px;">
            <tr>
                <td style="font-size: 14px;text-align: center;">
                    This is a computer generated proforma and does not require any stamp or signature
                </td>
            </tr>
        </table>
        <table class="footer-table">
        <tr>
          <td>
            Cactus Communications Inc.
          </td>
        </tr>
        <tr>
          <td>214 Carnegie Center, Suite 102, Princeton, NJ 08540, USA</td>
        </tr>
        <tr>
          <td>T: +1(267)-332-0051 F: +1(267) 332-0052</td>
        </tr>
        <tr>
          <td>
            <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
          </td>
        </tr>
        </table>
        </div>`,
            contactDetails: `<tbody>
        <tr>
            <td>
                <p><strong>Company : </strong>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Company]]</p>
            </td>
        </tr>
        <tr>
            <td>
                <p><strong>Client Contact : </strong>&nbsp;&nbsp;[[ClientContact1]]</p>
                [[ClientContact]]
            </td>
        </tr>
        <tr>
            <td>
                <p><strong>Email : </strong>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">[[Email]]</a>
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p><strong>Phone : </strong>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Phone]]
                </p>
            </td>
        </tr>
        </tbody>`,
            contactDetails2: `<tbody>
        <tr>
            <td>
                <p><strong>Address : </strong>&nbsp;&nbsp;[[Address1]]</p>
                [[AddressMulti]]
            </td>
        </tr>
        </tbody>`,
            address2: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;[[Address2]]</p>`,
            address3: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;[[Address3]]</p>`,
            address4: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;[[Address4]]</p>`,
            clientcontact2: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[ClientContact2]]</p>`,
            purchaseOrder: `<strong>Purchase Order number : </strong>[[PurchaseOrderNumber]]`,
            invoiceDetail: `<thead>
            <tr>
                <th>
                    Date
                </th>
                <th>
                    Service Details
                </th>
                <th>
                    Fees
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    [[InvoiceDate]]
                </td>
                <td>
                    [[InvoiceServiceDetails]]
                </td>
                <td>
                    [[CurrencySymbol]] [[InvoiceFees]]<span>*</span>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    Total
                </td>
                <td>
                    [[CurrencySymbol]] [[Total]]
                </td>
            </tr>
        </tbody>`,
            paymentInstructions: `<ul>
        <li>Please make your payment within 75 days of receiving this proforma. For any questions
            regarding your
            account<br />
            contact <a href="#">payments@cactusglobal.com</a></li>
        </ul>`,
            paymentDetails: `<ul>
            <li>
                <strong>Payment by bank transfer:</strong><br />
                Bank name: Citibank NA, 785 Fifth Avenue, New York, NY 10022<br />
                Account #: 9943387205<br />
                Account name: Cactus Communications Inc.<br />
                ABA/Routing #: 021 0000 89<br />
                Purpose: Payment for Invoice – [[InvoiceNumber]]<br />
                Recipient Address: 2 Neshaminy Interplex, Suite 100, Trevose, PA 19053<br />
                Recipient Phone: 267-332-0051
            </li>
        </ul>`,
            appendix: `<figure>
        <table>
            <thead>
                <tr>
                    <th>
                        DV code
                    </th>
                    <th>
                        Cactus SP Code
                    </th>
                    <th>
                        Project title
                    </th>
                    <th>
                        Amount
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        [[DvCode]]
                    </td>
                    <td>
                        [[CactusSpCode]]
                    </td>
                    <td>
                        [[ProjectTitle]]
                    </td>
                    <td>
                        [[CurrencySymbol]] [[Amount]]
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        Total
                    </td>
                    <td>
                        [[CurrencySymbol]] [[Total]]
                    </td>
                </tr>
            </tbody>
        </table>
        </figure>`
        };

        this.JapanTemplate = {
            headerCreate: `<header id="header">
        <div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background: #c5d3e5;">
        <td class="header-left">
        Proforma No : &nbsp;&nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
        Proforma Date : [[InvoiceDate]] <br />
        Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]]) <br />
          <label>[[Invoice]]</label>
        </td>
        <td class="header-right">
          <span>
              <img class="logo-img"
              src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
          </span>
        </td>
        </tr>
        </tbody>
        </table>
        </div>
        </header>`,
            footerCreate: `<footer id="footer">
        <div>
        <table style="margin-top:10px;">
            <tr>
                <td style="font-size: 14px;text-align: center;">
                    This is a computer generated proforma and does not require any signature
                </td>
            </tr>
        </table>
        <table class="footer-table">
        <tr>
        <td>
            <P>カクタス・コミュニケーションズ株式会社</P>
        </td>
        </tr>
        <tr>
            <td><p>〒101-0061 東京都千代田区神田三崎町2-4-1 TUG-Iビル4階 </p></td>
        </tr>
        <tr>
            <td><p>T: 03-6261-2290 F: 03-4496-4557</p></td>
        </tr>
        <tr><td>
            <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
        </td></tr>
        </table>
        </div>
        </footer>`,
            maincontent: `    <div id="main_content">
        <div style="height:1300px;">
        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">
                        CONTACT DETAILS</td>
                </tr>
            </tbody>
        </table>
        <div class="contact_details_japan">
        <div id="contact_details">
        <p><strong>Company : </strong>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Company]]</p>
        <p><strong>Client Contact : </strong>
        <span style="display: inline-flex;">&nbsp;&nbsp;[[ClientContact1]]</span>
        </p>
        </div>
        </div>
        <table style="margin: 15px 0">
        <tbody>
            <tr>
                <td class="table-heading">
                    PURCHASE ORDER DETAIL</td>
            </tr>
        </tbody>
        </table>
        <p id="purchaseOrder" class="purchaseOrder">
            <tr>
                <td>
                    <p>
                        <strong> Purchase Order number : </strong> [[PurchaseOrderNumber]] 
                    </p>
                </td>
            </tr>
        </p>
        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">
                        Proforma DETAIL
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="invoice-table proformaDetail">
            <div id="invoiceDetail" style="margin-bottom: 10px;">
                <table border="0" cellspacing="0" cellpadding="0">
                <thead>
                <tr>
                    <th>
                        Date
                    </th>
                    <th>
                        Service Details
                    </th>
                    <th>
                        Fees
                    </th>
                </tr>
            </thead>
            <tbody>
            <tr>
            <td>
                <p>[[InvoiceDate]]</p>
            </td>
            <td>
                <p>[[InvoiceServiceDetails]]</p>
            </td>
            <td>
                <p>[[CurrencySymbol]] [[InvoiceFees]]<span>*</span></p>
            </td>
            </tr>
            <tr>
                <td>
                    <p style="text-align: center;font-size: 16px;margin: 15px 0;">[[InvoiceDate]]</p>
                </td>
                <td>
                    <p style="padding-left: 15px;font-size: 16px;">Consumption Tax @ 8%</p>
                </td>
                <td>
                    <p style="font-size: 16px;text-align: center;font-weight: bold;">[[CurrencySymbol]] [[ConsumptionTax]]</p>
                </td>
            </tr>
            <tr>
                <td></td>
                <td style="text-align: center;font-weight: bold; font-size: 16px;">
                    <p>Total</p>
                </td>
                <td>
                    <p style="text-align: center;font-weight: bold; font-size: 16px;">[[CurrencySymbol]] [[Total]]</p>
                </td>
            </tr>
            </tbody>
                </table>
                <p style="font-size: 15px;font-weight: 600;">* Please refer to Appendix 1 for additional details</p>
            </div>
        </div>
        <tbody>
            <tr>
                <td>
                    <label style="font-size: 18px;font-weight: bold;margin-left: 0;">
                        PAYMENT INSTRUCTIONS
                    </label>
                </td>
            </tr>
        </tbody>
        <tbody class="paymentDetails">
            <tr>
                <td style="font-size:14px">
                    <div class="paymentInstructions">
                    <label>
                    振込先銀行：三菱UFJ銀行 品川駅前支店(店番588) 普通預金 2406331<br/>
                    口座名義：カクタスコミュニケーションズカブシキガイシャ
                    </label>
                    <label>振込先銀行：三菱UFJ銀行 品川駅前支店(店番588) 普通預金 2406331<br/>
                    口座名義：カクタスコミュニケーションズカブシキガイシャ
                    </label>
                    </div>
                    <ul id="paymentInstructions">
                    <li>
                        振込手数料はお客様ご負担でお願いいたします
                    </li>
                    <li>
                    この請求書が届いてから<span class="paymentDetails">60</span>日以内にお支払いをお願いいたします
                    </li>
                    <li>
                        正式な書類として弊社の電子押印で発行しております
                    </li>
                    </ul>
                </td>
            </tr>
        </tbody>
        <table class="signature-table">
            <!-- <tr>
                <td>
                    <img src="stamp.png">
                </td>
            </tr> -->

            <tr>
                <td>
                    <p style="font-size:15px;margin-top: 60px">
                        カクタス・コミュニケーションズ株式会社</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="font-size:15px">
                        〒101-0061 東京都千代田区神田三崎町2-4-1</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="font-size:15px">
                        TUG-Iビル4階</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="font-size:15px">
                        代表取締役 湯浅 誠</p>
                </td>
            </tr>

        </table>
        </div>
        [[APPENDIX]]
        </div>`,
        appendixCreate: `<table style="margin: 15px 0">
        <tbody>
            <tr>
                <td class="table-heading">
                    APPENDIX 1</td>
            </tr>
        </tbody>
    </table>
    <div class="invoice-table">
        <div id="appendix">
        <table>
        <thead>
            <tr style="text-align: center; font-size: 16px; font-weight: bold;">
                <th>
                    Project Code
                </th>
                <th>
                    Title
                </th>
                <th>
                    Amount
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="font-weight:normal;">
                    [[ProjectCode]]
                </td>
                <td style="font-weight:normal;">
                    [[Title]]
                </td>
                <td>
                    [[CurrencySymbol]] [[Amount]]
                </td>
            </tr>
        </tbody>
        </table>
        </div>
    </div>`,
        header: `<div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background: #c5d3e5;">
        <td class="header-left">
        Proforma No : &nbsp;&nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
        Proforma Date : &nbsp;[[InvoiceDate]] <br />
        Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]]) <br />
          <label>[[Invoice]]</label>
        </td>
        <td class="header-right">
          <span>
              <img class="logo-img"
              src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
          </span>
        </td>
        </tr>
        </tbody>
        </table>
        </div>`,
            footer: `<div>
      <table style="margin-top:10px;">
          <tr>
              <td style="font-size: 14px;text-align: center;">
                  This is a computer generated proforma and does not require any signature
              </td>
          </tr>
      </table>
      <table class="footer-table">
        <tr>
        <td>
            <P>カクタス・コミュニケーションズ株式会社</P>
        </td>
        </tr>
        <tr>
            <td><p>〒101-0061 東京都千代田区神田三崎町2-4-1 TUG-Iビル4階 </p></td>
        </tr>
        <tr>
            <td><p>T: 03-6261-2290 F: 03-4496-4557</p></td>
        </tr>
        <tr><td>
            <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
        </td></tr>
        </table>
        </div>`,
            contactDetails: `<p><strong>Company : </strong>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Company]]</p>
        <p><strong>Client Contact : </strong>
        <span style="display: inline-flex;">&nbsp;&nbsp;[[ClientContact1]]</span>
        </p>`,
            purchaseOrder: `<strong> Purchase Order number : </strong> [[PurchaseOrderNumber]] `,
            invoiceDetail: `<thead>
            <tr>
                <th>
                    Date
                </th>
                <th>
                    Service Details
                </th>
                <th>
                    Fees
                </th>
            </tr>
        </thead>
        <tbody>
        <tr>
        <td>
            <p>[[InvoiceDate]]</p>
        </td>
        <td>
            <p>[[InvoiceServiceDetails]]</p>
        </td>
        <td>
            <p>[[CurrencySymbol]] [[InvoiceFees]]<span>*</span></p>
        </td>
        </tr>
        <tr>
            <td>
                <p style="text-align: center;font-size: 16px;margin: 15px 0;">[[InvoiceDate]]</p>
            </td>
            <td>
                <p style="padding-left: 15px;font-size: 16px;">Consumption Tax @ 8%</p>
            </td>
            <td>
                <p style="font-size: 16px;text-align: center;font-weight: bold;">[[CurrencySymbol]] [[ConsumptionTax]]</p>
            </td>
        </tr>
        <tr>
            <td></td>
            <td style="text-align: center;font-weight: bold; font-size: 16px;">
                <p>Total</p>
            </td>
            <td>
                <p style="text-align: center;font-weight: bold; font-size: 16px;">[[CurrencySymbol]] [[Total]]</p>
            </td>
        </tr>
        </tbody>`,
            paymentInstructions: `<label>
        振込先銀行：三菱UFJ銀行 品川駅前支店(店番588) 普通預金 2406331<br/>
        口座名義：カクタスコミュニケーションズカブシキガイシャ
        </label>
        <label>振込先銀行：三菱UFJ銀行 品川駅前支店(店番588) 普通預金 2406331<br/>
        口座名義：カクタスコミュニケーションズカブシキガイシャ
        </label>`,
            paymentDetails: `<li>
            振込手数料はお客様ご負担でお願いいたします
        </li>
        <li>
        この請求書が届いてから<span class="paymentDetails">60</span>日以内にお支払いをお願いいたします
        </li>
        <li>
            正式な書類として弊社の電子押印で発行しております
        </li>`,
            appendix: `<table>
        <thead>
            <tr style="text-align: center; font-size: 16px; font-weight: bold;">
                <th>
                    Project Code
                </th>
                <th>
                    Title
                </th>
                <th>
                    Amount
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="font-weight:normal;">
                    [[ProjectCode]]
                </td>
                <td style="font-weight:normal;">
                    [[Title]]
                </td>
                <td>
                    [[CurrencySymbol]] [[Amount]]
                </td>
            </tr>
        </tbody>
    </table>`
        };

        this.IndiaTemplate = {
            headerCreate: `<header id=header>
        <div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background: #c5d3e5;">
        <td class="header-left">
        <span>
              <img style="margin-bottom: 20px;" class="logo-img"
              src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
        </span>
        <p>
            GST Proforma No: <br />
            Proforma No: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
            Proforma Date : &nbsp;&nbsp;&nbsp;[[InvoiceDate]]<br />
            Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]])</p>
        </td>
        <td class="header-center">
            <label>TAX Proforma</label>
        </td>
        <td class="header-right-label">
            <p>Original for Recipient</p>
        </td>
        </tr>
        </tbody>
        </table>
        </div>
        </header>`,
            footerCreate: `<footer id="footer">
        <div>
      <table style="margin-top:10px;">
          <tr>
              <td style="font-size: 14px;text-align: center;">
                  This is a computer generated proforma and does not require any stamp or signature
              </td>
          </tr>
      </table>
      <table class="footer-table">
      <tr>
            <td>
                <P>Cactus Communications Pvt. Ltd. (CIN U64200MH2002PTC137488)</P>
            </td>
        </tr>
        <tr>
            <td>
                <p>510 Shalimar Morya Park, Off Link Road, Andheri (W), Mumbai 400053, India </p>
            </td>
        </tr>
        <tr>
            <td>
                <p>T: +91 22 67148888 F: +91 22 67148889 </p>
            </td>
        </tr>
        <tr>
            <td>
                <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
            </td>
        </tr>
        </table>
        </div>
        </footer>`,
            maincontent: `<div id="main_content">
        <div style="height:1300px;">
        <table style="margin: 15px 0;">
            <tbody>
                <tr>
                    <td class="table-heading">
                        CONTACT DETAILS</td>
                </tr>
            </tbody>
        </table>

        <div class="contact_details-table">
            <div id="contact_details">
                <table style="width:54%;">
                <tbody>
            <tr>
                <td>
                    <p><strong>Company : </strong>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [[Company]]</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Client Contact : </strong>
                        <span>&nbsp;&nbsp;&nbsp;[[ClientContact]]</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Place of Supply : </strong>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Client GST no : </strong>

                </td>
            </tr>
            </tbody>
            </table>
            <table style="width:40%;">
            <tbody>
            <tr>
                <td>
                    <p><strong>Phone : </strong>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Phone]]
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Designation : </strong>[[Designation]]
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Email : </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#">[[Email]]</a>
                    </p>
                </td>
            </tr>
            </tbody>
            </table>
            <table>
            <tbody>
            <tr>
            <td>
                <p><strong>Address : </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;[[Address1]]</p>[[AddressMulti]]
            </td>
            </tr>
            </tbody>
            </table>
            </div>
        </div>

        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">REFERENCE DETAILS</td>
                </tr>
            </tbody>
        </table>

        <div id="referenceDetail" class="referenceDetail">
            <table>
                <tbody>
                <tr>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px">
                    <strong> Purchase Order number : </strong>  [[PurchaseOrderNumber]]  </p>
                </td>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px">
                    <strong> GST no : </strong> 27AACCC1194L1ZI  </p>
                </td>
            </tr>
            <tr>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px;margin: 0;">
                    <strong> PAN No : </strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AACCC1194L  </p>
                </td>
            </tr>
            </tbody>
            </table>
        </div>


        <table style="margin: 15px 0">
            <tbody>
                <tr>
                    <td class="table-heading">
                    Proforma DETAIL
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="invoice-table proformaDetail">
            <div id="invoiceDetail" style="margin-bottom: 20px;">
                <table border="0" cellspacing="0" cellpadding="0">
                <thead>
        <tr style="text-align: center; font-size: 16px; font-weight: bold;">
            <th>
                Date
            </th>
            <th>
                Service
            </th>
            <th>
                Service Accounting Code
            </th>
            <th>
                Fees
            </th>
        </tr>
        </thead>
            <tbody>
            <tr>
            <td style="width:12%;">
                [[InvoiceDate]]
            </td>
            <td>
                [[InvoiceServiceDetails]]
            </td>
            <td>998399 (Other Professional, Technical and Business Services n. e. c.)</td>
            <td>
                [[CurrencySymbol]] [[InvoiceFees]]<span>*</span>
            </td>
            </tr>
            <tr>
            <td>
            [[InvoiceDate]]
            </td>
            <td>
                Integrated Tax @ 18.00%
            </td>
            <td></td>
            <td>
                [[CurrencySymbol]] [[CentralTax]]
            </td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td style="text-align: center;">
                Total
            </td>
            <td>
                [[CurrencySymbol]] [[Total]]
            </td>
            </tr>
            </tbody>
            </table>
                <p style="font-size: 15px;font-weight: 600;">* Please refer to Appendix 1 for additional details</p>
            </div>
        </div>

        <tbody>
            <tr>
                <td>
                    <label style="font-size: 18px;font-weight: bold;margin-left: 0;">
                        PAYMENT INSTRUCTIONS
                    </label>
                </td>
            </tr>
        </tbody>

        <tbody>
            <tr>
                <td style="font-size:14px">
                    <div id="paymentInstructions">
                    <ul>
                    <li>Please make your payment within 60 days of receiving this proforma. For any questions regarding your account<br />
                    contact <a href="#">payments@cactusglobal.com</a></li>
                    </ul>
                    </div>
                    <div class="paymentDetails">
                        <ul>
                        <li>
                            <strong>Payment by NEFT/RTGS
                            (Please note the transfer charges will be borne by you):</strong>
                            <p>Bank name:  Citibank NA</p>
                            <p style="display: inline-flex">Bank address: <span> Citibank N.A. Times Square IT Park branch, Wing B,
                            Unit No. 1, Andheri-Kurla Road,<br />
                            Marol, Andheri (E), Mumbai – 400 059.</span></p>
                            <p>Branch name: Andheri (E), Mumbai, India</p>
                            <p>IFSC: CITI0100000</p>
                            <p>Account #:  0256594118</p>
                            <p>Beneficiary Name : Cactus Communications Pvt. Ltd.</p>
                            <p>Beneficiary Address : 510 Shalimar Morya Park, Off Link Road, Andheri (W), Mumbai 400053, India</p>
                            <p>Recipient Phone : +91 22 67148888 </p>
                        </li>
                        </ul>
                    </div>
                </td>
            </tr>
        </tbody>
        </div>
        [[APPENDIX]]
        </div>`,
        appendixCreate: `<table style="margin: 15px 0">
        <tbody>
            <tr>
                <td class="table-heading">
                    APPENDIX 1</td>
            </tr>
        </tbody>
        </table>

        <div class="invoice-table appendix">
            <div id="appendix">
            <table>
        <thead>
            <tr style="text-align: center; font-size: 16px; font-weight: bold;">
                <th>
                    Project Code
                </th>
                <th style="width: 50%;">
                    Title
                </th>
                <th>
                    Client POC
                </th>
                <th>
                    Amount
                </th>
             </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    [[ProjectCode]]
                </td>
                <td>
                    [[Title]]
                </td>
                <td>
                    [[ClientPOC]]
                </td>
                <td style="font-weight: bold;">
                   [[CurrencySymbol]] [[Amount]]
                </td>
            </tr>
        </tbody>
        </table>
            </div>
        </div>`,
        header: `<div>
        <table cellpadding="15" cellspacing="0">
            <tbody>
                <tr style="background: #c5d3e5;">
        <td class="header-left">
        <span>
              <img style="margin-bottom: 20px;" class="logo-img"
              src="https://cactusglobal.sharepoint.com/:i:/s/medcomcdn/EWR1GHbosaFDvGM_F_SztpwBdGEOEaYmMAnQ38DJfzQAvA">
        </span>
        <p>
            GST Proforma No: <br />
            Proforma No: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[InvoiceNumber]] <br />
            Proforma Date : &nbsp;&nbsp;&nbsp;[[InvoiceDate]]<br />
            Currency : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[CurrencyName]] ([[CurrencySymbol]])</p>
        </td>
        <td class="header-center">
            <label>TAX Proforma</label>
        </td>
        <td class="header-right-label">
            <p>Original for Recipient</p>
        </td>
        </tr>
        </tbody>
        </table>
        </div>`,
            footer: `<div>
      <table style="margin-top:10px;">
          <tr>
              <td style="font-size: 14px;text-align: center;">
                  This is a computer generated proforma and does not require any stamp or signature
              </td>
          </tr>
      </table>
      <table class="footer-table">
      <tr>
            <td>
                <P>Cactus Communications Pvt. Ltd. (CIN U64200MH2002PTC137488)</P>
            </td>
        </tr>
        <tr>
            <td>
                <p>510 Shalimar Morya Park, Off Link Road, Andheri (W), Mumbai 400053, India </p>
            </td>
        </tr>
        <tr>
            <td>
                <p>T: +91 22 67148888 F: +91 22 67148889 </p>
            </td>
        </tr>
        <tr>
            <td>
                <a href="http://www.cactusglobal.com/">www.cactusglobal.com</a>
            </td>
        </tr>
        </table>
        </div>`,
            contactDetails1: `<tbody>
            <tr>
                <td>
                    <p><strong>Company : </strong>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [[Company]]</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Client Contact : </strong>
                        <span>&nbsp;&nbsp;&nbsp;[[ClientContact]]</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Place of Supply : </strong>
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Client GST no : </strong>

                </td>
            </tr>
        </tbody>`,
            address2: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Address2]]</p>`,
            address3: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Address3]],</p>`,
            address4: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Address4]]</p>`,
            address5: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Address5]],</p>`,
            address6: `<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Address6]]</p>`,
            contactDetails2: `<tbody>
            <tr>
                <td>
                    <p><strong>Phone : </strong>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[Phone]]
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Designation : </strong>[[Designation]]
                </td>
            </tr>
            <tr>
                <td>
                    <p><strong>Email : </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#">[[Email]]</a>
                    </p>
                </td>
            </tr>
        </tbody>`,
            address: `<tbody>
        <tr>
        <td>
            <p><strong>Address : </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;[[Address1]]</p>[[AddressMulti]]
        </td>
        </tr>
        </tbody>`,
            purchaseOrder: `<tr>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px">
                    <strong> Purchase Order number : </strong> [[PurchaseOrderNumber]]  </p>
                </td>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px">
                    <strong> GST no : </strong> 27AACCC1194L1ZI  </p>
                </td>
            </tr>
            <tr>
                <td style="width: 40%; float: left;text-align: left;">
                    <p style="font-size:15px;margin: 0;">
                    <strong> PAN No : </strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AACCC1194L  </p>
                </td>
            </tr>`,
            invoiceDetail: `<thead>
        <tr style="text-align: center; font-size: 16px; font-weight: bold;">
            <th>
                Date
            </th>
            <th>
                Service
            </th>
            <th>
                Service Accounting Code
            </th>
            <th>
                Fees
            </th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="width:12%;">
                [[InvoiceDate]]
            </td>
            <td>
                [[InvoiceServiceDetails]]
            </td>
            <td>998399 (Other Professional, Technical and Business Services n. e. c.)</td>
            <td>
                [[CurrencySymbol]] [[InvoiceFees]]<span>*</span>
            </td>
        </tr>
        <tr>
            <td>
            [[InvoiceDate]]
            </td>
            <td>
                Integrated Tax @ 18.00%
            </td>
            <td></td>
            <td>
                [[CurrencySymbol]] [[CentralTax]]
            </td>
        </tr>
        <!-- <tr>
            <td>
                [[InvoiceDate]]
            </td>
            <td>
                State Tax @ 9.00%
            </td>
            <td></td>
            <td>
                [[CurrencySymbol]] [[StateTax]]
            </td>
        </tr> -->
        <tr>
            <td></td>
            <td></td>
            <td style="text-align: center;font-weight: bold; font-size: 16px;">
                Total
            </td>
            <td>
                [[CurrencySymbol]] [[Total]]
            </td>
        </tr>
    </tbody>`,
            paymentInstructions: `<ul>
        <li>Please make your payment within 60 days of receiving this proforma. For any questions regarding your account<br />
        contact <a href="#">payments@cactusglobal.com</a></li>
        </ul>`,
            paymentDetails: `<ul>
            <li>
                <strong>Payment by NEFT/RTGS
                (Please note the transfer charges will be borne by you):</strong>
                <p>Bank name:  Citibank NA</p>
                <p style="display: inline-flex">Bank address: <span> Citibank N.A. Times Square IT Park branch, Wing B,
                Unit No. 1, Andheri-Kurla Road,<br />
                Marol, Andheri (E), Mumbai – 400 059.</span></p>
                <p>Branch name: Andheri (E), Mumbai, India</p>
                <p>IFSC: CITI0100000</p>
                <p>Account #:  0256594118</p>
                <p>Beneficiary Name : Cactus Communications Pvt. Ltd.</p>
                <p>Beneficiary Address : 510 Shalimar Morya Park, Off Link Road, Andheri (W), Mumbai 400053, India</p>
                <p>Recipient Phone : +91 22 67148888 </p>
            </li>
        </ul>`,
            appendix: `<table>
        <thead>
            <tr style="text-align: center; font-size: 16px; font-weight: bold;">
                <th>
                    Project Code
                </th>
                <th style="width: 50%;">
                    Title
                </th>
                <th>
                    Client POC
                </th>
                <th>
                    Amount
                </th>
             </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    [[ProjectCode]]
                </td>
                <td>
                    [[Title]]
                </td>
                <td>
                    [[ClientPOC]]
                </td>
                <td style="font-weight: bold;">
                   [[CurrencySymbol]] [[Amount]]
                </td>
            </tr>
        </tbody>
    </table>`
        };

    }

    getInvoiceData(invoicedata: any) {
        // this.address = '';
        // this.clientContact = '';
        // this.invoicedata.serviceDetails = 'April Invoice for PO #8300324481 (5 Manuscripts and 1 Poster)';
        // this.invoicedata.invoiceFees = '30,687.50';
        // this.invoicedata.total = '30,687.50';

        // // const copyItem: any = Object.assign({}, this.USTemplate);
        // this.USHtmlObject.header = this.USHtmlObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        // this.USHtmlObject.header = this.USHtmlObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        // this.USHtmlObject.header = this.USHtmlObject.header.replace('[[CurrencyName]]', this.invoicedata.usCurrencyName);
        // this.USHtmlObject.header = this.USHtmlObject.header.replace('[[CurrencySymbol]]', this.invoicedata.usCurrencySymbol);
        // this.USHtmlObject.header = this.USHtmlObject.header.replace('[[Invoice]]', this.invoicedata.invoice);
        // this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[Company]]', this.invoicedata.company);
        // this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[ClientContact1]]', this.invoicedata.clientcontact1);
        // this.USHtmlObject.clientcontact2 = this.USHtmlObject.clientcontact2.replace('[[ClientContact2]]', this.invoicedata.clientcontact2);
        // this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[Email]]', this.invoicedata.email);
        // this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[Phone]]', this.invoicedata.phone);
        // this.USHtmlObject.contactDetails2 = this.USHtmlObject.contactDetails2.replace('[[Address1]]', this.invoicedata.address1);
        // // this.USHtmlObject.address2 = this.USHtmlObject.address2.replace('[[Address2]]', this.invoicedata.address2);
        // // this.USHtmlObject.address3 = this.USHtmlObject.address3.replace('[[Address3]]', this.invoicedata.address3);
        // // this.USHtmlObject.address4 = this.USHtmlObject.address4.replace('[[Address4]]', this.invoicedata.address4);
        // this.USHtmlObject.purchaseOrder = this.USHtmlObject.purchaseOrder.replace('[[PurchaseOrderNumber]]',
        //     this.invoicedata.purchaseOrderNumber);
        // if (this.invoicedata.address2 != null && this.invoicedata.address2.trim() !== '' && this.invoicedata.address2 !== undefined) {
        //     this.address = this.address + this.USHtmlObject.address2;
        //     console.log(this.address);
        // }
        // if (this.invoicedata.address3 != null && this.invoicedata.address3.trim() !== '' && this.invoicedata.address3 !== undefined) {
        //     this.address = this.address + this.USHtmlObject.address3;
        //     console.log(this.address);
        // }
        // if (this.invoicedata.address4 != null && this.invoicedata.address4.trim() !== '' && this.invoicedata.address4 !== undefined) {
        //     this.address = this.address + this.USHtmlObject.address4;
        //     console.log(this.address);
        // }
        // if (this.address !== null && this.address.trim() !== '' && this.address !== undefined) {
        //     this.USHtmlObject.contactDetails2 = this.USHtmlObject.contactDetails2.replace('[[AddressMulti]]', this.address);
        //     console.log(this.address);
        // } else {
        // this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[AddressMulti]]', this.address);
        // }

        // if (this.invoicedata.clientcontact2 != null && this.invoicedata.clientcontact2.trim() !== ''
        // && this.invoicedata.clientcontact2 !== undefined) {
        //     this.clientContact = this.clientContact + this.USHtmlObject.clientcontact2;
        // }

        // if (this.clientContact !== null && this.clientContact.trim() !== '' && this.clientContact !== undefined) {
        //     this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[ClientContact]]', this.clientContact);
        //     // console.log(this.clientContact);
        // } else {
        //     this.USHtmlObject.contactDetails = this.USHtmlObject.contactDetails.replace('[[ClientContact]]', this.clientContact);
        // }

        // this.USHtmlObject.paymentDetails = this.USHtmlObject.paymentDetails.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        // this.USHtmlObject.invoiceDetail = this.USHtmlObject.invoiceDetail.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);

        // this.USHtmlObject.invoiceDetail = this.USHtmlObject.invoiceDetail.replace('[[InvoiceServiceDetails]]', 
        // this.invoicedata.serviceDetails);

        // this.USHtmlObject.invoiceDetail = this.USHtmlObject.invoiceDetail.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        // this.USHtmlObject.invoiceDetail = this.USHtmlObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total);
        // this.USHtmlObject.invoiceDetail = this.USHtmlObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.usCurrencySymbol);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace('[[DvCode]]', this.invoicedata.dvCode);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace('[[CactusSpCode]]', this.invoicedata.cactusSPCode);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace('[[ProjectTitle]]', this.invoicedata.projectTitle);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace('[[Amount]]', this.invoicedata.Amount);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace('[[Total]]', this.invoicedata.total_US);
        // this.USHtmlObject.appendix = this.USHtmlObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.usCurrencySymbol);

        // console.log(this.USHtmlObject)
        

        // console.log(document.getElementById('header').innerHTML);
        // document.getElementById('header').innerHTML = this.USHtmlObject.header;
        // document.getElementById('footer').innerHTML = this.USHtmlObject.footer;
        // document.getElementById('contactDetails1').innerHTML = this.USHtmlObject.contactDetails;
        // document.getElementById('contactDetails2').innerHTML = this.USHtmlObject.contactDetails2;
        // document.getElementById('purchaseOrderDetails').innerHTML = this.USHtmlObject.purchaseOrder;
        // document.getElementById('invoiceDetails').innerHTML = this.USHtmlObject.invoiceDetail;
        // document.getElementById('paymentInstructions').innerHTML = this.USHtmlObject.paymentInstructions;
        // document.getElementById('paymentDetails').innerHTML = this.USHtmlObject.paymentDetails;
        // document.getElementById('appendix').innerHTML = this.USHtmlObject.appendix;
    }

    getJapanInvoiceData(invoicedata: {}) {
        // this.invoicedata.serviceDetails1 = 'EXPLORE-J STUDY: FH diagnosis slide deck first draft delivered';
        // this.invoicedata.invoiceFees1 = '540,000.00';
        // this.invoicedata.consumptionTax = '43,200.00';
        // this.invoicedata.total1 = '583,200.00';

        // const JapanInvoice: any = Object.assign({}, this.JapanTemplate);
        // this.japanHtmlObject.header = this.japanHtmlObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        // this.japanHtmlObject.header = this.japanHtmlObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        // this.japanHtmlObject.header = this.japanHtmlObject.header.replace('[[Invoice]]', this.invoicedata.invoice);
        // this.japanHtmlObject.header = this.japanHtmlObject.header.replace('[[CurrencyName]]', this.invoicedata.JpnCurrencyName);
        // this.japanHtmlObject.header = this.japanHtmlObject.header.replace('[[CurrencySymbol]]', this.invoicedata.JpnCurrencySymbol);
        // this.japanHtmlObject.contactDetails = this.japanHtmlObject.contactDetails.replace('[[Company]]', this.invoicedata.company);
        // this.japanHtmlObject.contactDetails = this.japanHtmlObject.contactDetails.replace('[[ClientContact1]]',
        //     this.invoicedata.clientcontact1);
        // this.japanHtmlObject.purchaseOrder = this.japanHtmlObject.purchaseOrder.replace('[[PurchaseOrderNumber]]',
        //     this.invoicedata.purchaseOrderNumber);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
        //     this.invoicedata.invoice_date);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace('[[InvoiceServiceDetails]]',
        //     this.invoicedata.serviceDetails1);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees1);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace('[[ConsumptionTax]]', 
        // this.invoicedata.consumptionTax);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total1);
        // this.japanHtmlObject.invoiceDetail = this.japanHtmlObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.JpnCurrencySymbol);

        // this.japanHtmlObject.appendix = this.japanHtmlObject.appendix.replace('[[ProjectCode]]', this.invoicedata.projectCode_japan);
        // this.japanHtmlObject.appendix = this.japanHtmlObject.appendix.replace('[[Title]]', this.invoicedata.title);
        // this.japanHtmlObject.appendix = this.japanHtmlObject.appendix.replace('[[Amount]]', this.invoicedata.Amount1);
        // this.japanHtmlObject.appendix = this.japanHtmlObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.JpnCurrencySymbol);
    }

    getIndiaInvoiceData(invoicedata: {}) {
        // this.indAddress = '';
        // this.invoicedata.serviceDetails2 = 'Medcomm Copyedit Projects for April 2019';
        // this.invoicedata.invoiceFees2 = '219,802.50';
        // this.invoicedata.centralTax = '39,564.45';
        // this.invoicedata.stateTax = '19,782.22';
        // this.invoicedata.total2 = '259,366.95';

        // const IndiaInvoice: any = Object.assign({}, this.IndiaTemplate);
        // this.indiaHtmlObject.header = this.indiaHtmlObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        // this.indiaHtmlObject.header = this.indiaHtmlObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        // this.indiaHtmlObject.header = this.indiaHtmlObject.header.replace('[[CurrencyName]]', this.invoicedata.IndCurrencyName);
        // this.indiaHtmlObject.header = this.indiaHtmlObject.header.replace('[[CurrencySymbol]]', this.invoicedata.IndCurrencySymbol);

        // this.indiaHtmlObject.purchaseOrder = this.indiaHtmlObject.purchaseOrder.replace('[[PurchaseOrderNumber]]',
        //     this.invoicedata.purchaseOrderNumber);

        // this.indiaHtmlObject.contactDetails1 = this.indiaHtmlObject.contactDetails1.replace('[[Company]]', this.invoicedata.company1);
        // this.indiaHtmlObject.contactDetails1 = this.indiaHtmlObject.contactDetails1.replace('[[ClientContact]]',
        //     this.invoicedata.clientcontact);
        // this.indiaHtmlObject.address = this.indiaHtmlObject.address.replace('[[Address1]]', this.invoicedata.indaddress1);
        // // this.indiaHtmlObject.address2 = this.indiaHtmlObject.address2.replace('[[Address2]]', this.invoicedata.indaddress2);
        // // this.indiaHtmlObject.address3 = this.indiaHtmlObject.address3.replace('[[Address3]]', this.invoicedata.indaddress3);
        // // this.indiaHtmlObject.address4 = this.indiaHtmlObject.address4.replace('[[Address4]]', this.invoicedata.indaddress4);
        // // this.indiaHtmlObject.address5 = this.indiaHtmlObject.address5.replace('[[Address5]]', this.invoicedata.indaddress5);
        // // this.indiaHtmlObject.address6 = this.indiaHtmlObject.address6.replace('[[Address6]]', this.invoicedata.indaddress6);


        // this.indiaHtmlObject.contactDetails2 = this.indiaHtmlObject.contactDetails2.replace('[[Phone]]', this.invoicedata.indphone);
        // this.indiaHtmlObject.contactDetails2 = this.indiaHtmlObject.contactDetails2.replace('[[Designation]]',
        //     this.invoicedata.inddesignation);
        // this.indiaHtmlObject.contactDetails2 = this.indiaHtmlObject.contactDetails2.replace('[[Email]]', this.invoicedata.email1);

        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
        //     this.invoicedata.invoice_date);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace('[[InvoiceServiceDetails]]',
        //     this.invoicedata.serviceDetails2);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.IndCurrencySymbol);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace('[[InvoiceFees]]',
        // this.invoicedata.invoiceFees2);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace('[[CentralTax]]', this.invoicedata.centralTax);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace('[[StateTax]]', this.invoicedata.stateTax);
        // this.indiaHtmlObject.invoiceDetail = this.indiaHtmlObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total2);

        // // if (this.invoicedata.indaddress2 != null && this.invoicedata.indaddress2.trim() !== ''
        // // && this.invoicedata.indaddress2 !== undefined) {
        // //     this.indAddress = this.indAddress + this.indiaHtmlObject.address2;
        // //     console.log(this.indAddress);
        // // }
        // // if (this.invoicedata.indaddress3 != null && this.invoicedata.indaddress3.trim() !== ''
        // // && this.invoicedata.indaddress3 !== undefined) {
        // //     this.indAddress = this.indAddress + this.indiaHtmlObject.address3;
        // //     console.log(this.indAddress);
        // // }
        // // if (this.invoicedata.indaddress4 != null && this.invoicedata.indaddress4.trim() !== ''
        // // && this.invoicedata.indaddress4 !== undefined) {
        // //     this.indAddress = this.indAddress + this.indiaHtmlObject.address4;
        // //     console.log(this.indAddress);
        // // }
        // // if (this.invoicedata.indaddress5 != null && this.invoicedata.indaddress5.trim() !== ''
        // // && this.invoicedata.indaddress5 !== undefined) {
        // //     this.indAddress = this.indAddress + this.indiaHtmlObject.address5;
        // //     console.log(this.indAddress);
        // // }
        // // if (this.invoicedata.indaddress6 != null && this.invoicedata.indaddress6.trim() !== ''
        // // && this.invoicedata.indaddress6 !== undefined) {
        // //     this.indAddress = this.indAddress + this.indiaHtmlObject.address6;
        // //     console.log(this.indAddress);
        // // }
        // // if (this.indAddress !== null && this.indAddress.trim() !== '' && this.indAddress !== undefined) {
        // //     this.indiaHtmlObject.address = this.indiaHtmlObject.address.replace('[[AddressMulti]]', this.indAddress);
        // //     console.log(this.indAddress);
        // // } else {
        // // this.indiaHtmlObject.address = this.indiaHtmlObject.address.replace('[[AddressMulti]]', this.indAddress);
        // // // }

        // this.indiaHtmlObject.appendix = this.indiaHtmlObject.appendix.replace('[[ProjectCode]]', this.invoicedata.projectCode_ind);
        // this.indiaHtmlObject.appendix = this.indiaHtmlObject.appendix.replace('[[Title]]', this.invoicedata.title1);
        // this.indiaHtmlObject.appendix = this.indiaHtmlObject.appendix.replace('[[ClientPOC]]', this.invoicedata.clientPoc);
        // this.indiaHtmlObject.appendix = this.indiaHtmlObject.appendix.replace('[[Amount]]', this.invoicedata.Amount2);
        // this.indiaHtmlObject.appendix = this.indiaHtmlObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
        //     this.invoicedata.IndCurrencySymbol);

    }


    showDialog() {
        this.callInvoiceData({});
        this.display = true;
        this.USTemplateCopy = this.USHtmlObject;
    }

    showDialog1() {
        this.getJapanInvoiceData({});
        this.display1 = true;
        this.JapanTemplateCopy = this.japanHtmlObject;
    }

    showDialog2() {
        this.getIndiaInvoiceData({});
        this.display2 = true;
        this.IndiaTemplateCopy = this.indiaHtmlObject;
    }

    editable(id: string) {
        this.elementId = id;
        if (id === 'contact_details') {
            this.heading = 'Contact Details';
        }
        if (id === 'paymentInstructions') {
            this.heading = 'Payment Instructions';
        }
        if (id === 'appendix') {
            this.heading = 'Appendix';
        }
        this.editor = true;
        const mainUl = document.getElementById(id);
        const getLi = mainUl.getElementsByTagName('li')[1];
        if (getLi === null || getLi === undefined) {
            this.data = document.getElementById(id).innerHTML;
        } else {
            console.log(getLi.firstElementChild.innerHTML);
            this.data = getLi.firstElementChild.innerHTML;
        }
    }

    close() {
        this.editor = false;
    }

    createUSInvoice(invoiceData) {
        // originalTemplate
        // console.log(this.invoicedata);
        this.address = '';
        this.clientContact = '';

        const USInvoice: any = Object.assign({}, this.USTemplate);
        USInvoice.headerCreate = USInvoice.headerCreate.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        USInvoice.headerCreate = USInvoice.headerCreate.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        USInvoice.headerCreate = USInvoice.headerCreate.replace('[[CurrencyName]]', this.invoicedata.usCurrencyName);
        USInvoice.headerCreate = USInvoice.headerCreate.replace('[[CurrencySymbol]]', this.invoicedata.usCurrencySymbol);
        USInvoice.headerCreate = USInvoice.headerCreate.replace('[[Invoice]]', this.invoicedata.invoice);

        USInvoice.maincontent = USInvoice.maincontent.replace('[[Company]]', this.invoicedata.company);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[ClientContact1]]', this.invoicedata.clientcontact1);
        USInvoice.clientcontact2 = USInvoice.clientcontact2.replace('[[ClientContact2]]', this.invoicedata.clientcontact2);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[Email]]', this.invoicedata.email);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[Phone]]', this.invoicedata.phone);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[Address1]]', this.invoicedata.address1);
        USInvoice.address2 = USInvoice.address2.replace('[[Address2]]', this.invoicedata.address2);
        USInvoice.address3 = USInvoice.address3.replace('[[Address3]]', this.invoicedata.address3);
        USInvoice.address4 = USInvoice.address4.replace('[[Address4]]', this.invoicedata.address4);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[PurchaseOrderNumber]]', this.invoicedata.purchaseOrderNumber);
        // console.log(USInvoice.maincontent);

        if (this.invoicedata.address2 != null && this.invoicedata.address2.trim() !== '' && this.invoicedata.address2 !== undefined) {
            this.address = this.address + USInvoice.address2;
            // console.log(this.address);
        }
        if (this.invoicedata.address3 != null && this.invoicedata.address3.trim() !== '' && this.invoicedata.address3 !== undefined) {
            this.address = this.address + USInvoice.address3;
            // console.log(this.address);
        }
        if (this.invoicedata.address4 != null && this.invoicedata.address4.trim() !== '' && this.invoicedata.address4 !== undefined) {
            this.address = this.address + USInvoice.address4;
            // console.log(this.address);
        }
        if (this.address !== null && this.address.trim() !== '' && this.address !== undefined) {
            USInvoice.maincontent = USInvoice.maincontent.replace('[[AddressMulti]]', this.address);
            // console.log(this.address);
        } else {
            USInvoice.maincontent = USInvoice.maincontent.replace('[[AddressMulti]]', this.address);
        }

        if (this.invoicedata.clientcontact2 != null && this.invoicedata.clientcontact2.trim() !== ''
            && this.invoicedata.clientcontact2 !== undefined) {
            this.clientContact = this.clientContact + USInvoice.clientcontact2;
        }

        if (this.clientContact !== null && this.clientContact.trim() !== '' && this.clientContact !== undefined) {
            USInvoice.maincontent = USInvoice.maincontent.replace('[[ClientContact]]', this.clientContact);
            // console.log(this.clientContact);
        } else {
            USInvoice.maincontent = USInvoice.maincontent.replace('[[ClientContact]]', this.clientContact);
        }

        USInvoice.maincontent = USInvoice.maincontent.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);

        USInvoice.maincontent = USInvoice.maincontent.replace('[[InvoiceServiceDetails]]', this.invoicedata.serviceDetails);

        USInvoice.maincontent = USInvoice.maincontent.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        USInvoice.maincontent = USInvoice.maincontent.replace('[[Total]]', this.invoicedata.total);
        USInvoice.maincontent = USInvoice.maincontent.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.usCurrencySymbol);
        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace('[[DvCode]]', this.invoicedata.Appendix[0]);
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace('[[CactusSpCode]]', this.invoicedata.Appendix[1]);
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace('[[ProjectTitle]]', this.invoicedata.Appendix[2]);
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace('[[Total]]', this.invoicedata.Appendix[3]);
        USInvoice.appendixCreate = USInvoice.appendixCreate.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.usCurrencySymbol);
        } else {
            this.showAppendix = false;
        }
        // console.log(USInvoice.headerCreate);

        // const header = document.getElementById('header');
        let headerObj: any = this.headerstyle;
        headerObj = headerObj.replace('[[HeaderContent]]', USInvoice.headerCreate);
        console.log('Header Html', headerObj);

        // const content = document.getElementById('main_content');
        let contentObj: string = this.contentStyle;
        let outerData: string = USInvoice.maincontent;
        const appendix: string = USInvoice.appendixCreate;
        if (!this.showAppendix) {
            outerData = USInvoice.maincontent.replace('[[APPENDIX]]', '');
            contentObj = contentObj + outerData + '</body></html>';
        } else {
            outerData = USInvoice.maincontent.replace('[[APPENDIX]]', appendix);
            contentObj = contentObj + outerData + '</body></html>';
            console.log('Main Content Html', contentObj);

        }
        console.log('Main Content Html', contentObj);


        const footer = document.getElementById('footer');
        let footerObj: any = this.footerStyle;
        footerObj = footerObj.replace('[[FooterContent]]', USInvoice.footerCreate);
        console.log('Footer Html', footerObj);

        this.originalInvoice = {};
        this.originalInvoice.Header = headerObj;
        this.originalInvoice.Content = contentObj;
        this.originalInvoice.Footer = footerObj;

        console.log(this.originalInvoice.Content);

        this.address = '';
        this.clientContact = '';

        // Replaced US Invoice Template
        const USObject: any = Object.assign({}, this.USTemplate);
        USObject.header = USObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        USObject.header = USObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        USObject.header = USObject.header.replace('[[CurrencyName]]', this.invoicedata.usCurrencyName);
        USObject.header = USObject.header.replace('[[CurrencySymbol]]', this.invoicedata.usCurrencySymbol);
        USObject.header = USObject.header.replace('[[Invoice]]', this.invoicedata.invoice);
        USObject.contactDetails = USObject.contactDetails.replace('[[Company]]', this.invoicedata.company);
        USObject.contactDetails = USObject.contactDetails.replace('[[ClientContact1]]', this.invoicedata.clientcontact1);
        USObject.clientcontact2 = USObject.clientcontact2.replace('[[ClientContact2]]', this.invoicedata.clientcontact2);
        USObject.contactDetails = USObject.contactDetails.replace('[[Email]]', this.invoicedata.email);
        USObject.contactDetails = USObject.contactDetails.replace('[[Phone]]', this.invoicedata.phone);
        USObject.contactDetails2 = USObject.contactDetails2.replace('[[Address1]]', this.invoicedata.address1);
        USObject.address2 = USObject.address2.replace('[[Address2]]', this.invoicedata.address2);
        USObject.address3 = USObject.address3.replace('[[Address3]]', this.invoicedata.address3);
        USObject.address4 = USObject.address4.replace('[[Address4]]', this.invoicedata.address4);
        USObject.purchaseOrder = USObject.purchaseOrder.replace('[[PurchaseOrderNumber]]', this.invoicedata.purchaseOrderNumber);
        if (this.invoicedata.address2 != null && this.invoicedata.address2.trim() !== '' && this.invoicedata.address2 !== undefined) {
            this.address = this.address + USObject.address2;
            // console.log(this.address);
        }
        if (this.invoicedata.address3 != null && this.invoicedata.address3.trim() !== '' && this.invoicedata.address3 !== undefined) {
            this.address = this.address + USObject.address3;
            // console.log(this.address);
        }
        if (this.invoicedata.address4 != null && this.invoicedata.address4.trim() !== '' && this.invoicedata.address4 !== undefined) {
            this.address = this.address + USObject.address4;
            // console.log(this.address);
        }
        if (this.address !== null && this.address.trim() !== '' && this.address !== undefined) {
            USObject.contactDetails2 = USObject.contactDetails2.replace('[[AddressMulti]]', this.address);
            // console.log(this.address);
        } else {
            USObject.contactDetails2 = USObject.contactDetails2.replace('[[AddressMulti]]', this.address);
            console.log(USObject.contactDetails2);
        }

        if (this.invoicedata.clientcontact2 != null && this.invoicedata.clientcontact2.trim() !== ''
            && this.invoicedata.clientcontact2 !== undefined) {
            this.clientContact = this.clientContact + USObject.clientcontact2;
        }

        if (this.clientContact !== null && this.clientContact.trim() !== '' && this.clientContact !== undefined) {
            USObject.contactDetails = USObject.contactDetails.replace('[[ClientContact]]', this.clientContact);
            // console.log(this.clientContact);
        } else {
            USObject.contactDetails = USObject.contactDetails.replace('[[ClientContact]]', this.clientContact);
        }

        USObject.paymentDetails = USObject.paymentDetails.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        USObject.invoiceDetail = USObject.invoiceDetail.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);

        USObject.invoiceDetail = USObject.invoiceDetail.replace('[[InvoiceServiceDetails]]', this.invoicedata.serviceDetails);

        USObject.invoiceDetail = USObject.invoiceDetail.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        USObject.invoiceDetail = USObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total);
        USObject.invoiceDetail = USObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.usCurrencySymbol);
        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        USObject.appendix = USObject.appendix.replace('[[DvCode]]', this.invoicedata.Appendix[0]);
        USObject.appendix = USObject.appendix.replace('[[CactusSpCode]]', this.invoicedata.Appendix[1]);
        USObject.appendix = USObject.appendix.replace('[[ProjectTitle]]', this.invoicedata.Appendix[2]);
        USObject.appendix = USObject.appendix.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        USObject.appendix = USObject.appendix.replace('[[Total]]', this.invoicedata.Appendix[3]);
        USObject.appendix = USObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.usCurrencySymbol);
        } else {
            this.showAppendix = false;
            delete this.USHtmlObject.appendix;
        }

        this.USHtmlObject = USObject;
        console.log(this.USHtmlObject);

        delete this.USHtmlObject.maincontent;
        delete this.USHtmlObject.headerCreate;
        delete this.USHtmlObject.footerCreate;
        delete this.USHtmlObject.address2;
        delete this.USHtmlObject.address3;
        delete this.USHtmlObject.address4;

        const obj: any = {};
        obj.pdf = this.originalInvoice;
        obj.saveObj = this.USHtmlObject;

        console.log(obj);

        // this.common.createPdf(this.originalInvoice).subscribe(
        // (res) => {
        //     console.log(res);
        // }, (err) => console.log(err));
    }

    createJapanInvoice(invoiceData) {

        const JapanInvoice: any = Object.assign({}, this.JapanTemplate);
        JapanInvoice.headerCreate = JapanInvoice.headerCreate.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        JapanInvoice.headerCreate = JapanInvoice.headerCreate.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        JapanInvoice.headerCreate = JapanInvoice.headerCreate.replace('[[Invoice]]', this.invoicedata.invoice);
        JapanInvoice.headerCreate = JapanInvoice.headerCreate.replace('[[CurrencyName]]', this.invoicedata.JpnCurrencyName);
        JapanInvoice.headerCreate = JapanInvoice.headerCreate.replace('[[CurrencySymbol]]', this.invoicedata.JpnCurrencySymbol);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[Company]]', this.invoicedata.company);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[ClientContact1]]', this.invoicedata.clientcontact1);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[PurchaseOrderNumber]]', this.invoicedata.purchaseOrderNumber);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
            this.invoicedata.invoice_date);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[InvoiceServiceDetails]]', this.invoicedata.serviceDetails);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[ConsumptionTax]]', this.invoicedata.consumptionTax);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace('[[Total]]', this.invoicedata.total);
        JapanInvoice.maincontent = JapanInvoice.maincontent.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.JpnCurrencySymbol);
        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        JapanInvoice.appendixCreate = JapanInvoice.appendixCreate.replace('[[ProjectCode]]', this.invoicedata.Appendix[0]);
        JapanInvoice.appendixCreate = JapanInvoice.appendixCreate.replace('[[Title]]', this.invoicedata.Appendix[2]);
        JapanInvoice.appendixCreate = JapanInvoice.appendixCreate.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        JapanInvoice.appendixCreate = JapanInvoice.appendixCreate.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.JpnCurrencySymbol);
        }

        // const header = document.getElementById('header');
        let headerObj: any = this.headerstyle;
        headerObj = headerObj.replace('[[HeaderContent]]', JapanInvoice.headerCreate);
        console.log('Header Html', headerObj);

        // const content = document.getElementById('main_content');
        let contentObj: string = this.contentStyle;
        let outerData: string = JapanInvoice.maincontent;
        const appendix: string = JapanInvoice.appendixCreate;
        if (!this.showAppendix) {
            outerData = JapanInvoice.maincontent.replace('[[APPENDIX]]', '');
            contentObj = contentObj + outerData + '</body></html>';
        } else {
            outerData = JapanInvoice.maincontent.replace('[[APPENDIX]]', appendix);
            contentObj = contentObj + outerData + '</body></html>';
            console.log('Main Content Html', contentObj);

        }


        const footer = document.getElementById('footer');
        let footerObj: any = this.footerStyle;
        footerObj = footerObj.replace('[[FooterContent]]', JapanInvoice.footerCreate);
        console.log('Footer Html', footerObj);

        this.originalInvoice = {};
        this.originalInvoice.Header = headerObj;
        this.originalInvoice.Content = contentObj;
        this.originalInvoice.Footer = footerObj;
        // console.log(this.originalInvoice.Header);


        const JapanObject: any = Object.assign({}, this.JapanTemplate);
        // const JapanInvoice: any = Object.assign({}, this.JapanTemplate);
        JapanObject.header = JapanObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        JapanObject.header = JapanObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        JapanObject.header = JapanObject.header.replace('[[Invoice]]', this.invoicedata.invoice);
        JapanObject.header = JapanObject.header.replace('[[CurrencyName]]', this.invoicedata.JpnCurrencyName);
        JapanObject.header = JapanObject.header.replace('[[CurrencySymbol]]', this.invoicedata.JpnCurrencySymbol);
        JapanObject.contactDetails = JapanObject.contactDetails.replace('[[Company]]', this.invoicedata.company);
        JapanObject.contactDetails = JapanObject.contactDetails.replace('[[ClientContact1]]',
            this.invoicedata.clientcontact1);
        JapanObject.purchaseOrder = JapanObject.purchaseOrder.replace('[[PurchaseOrderNumber]]',
            this.invoicedata.purchaseOrderNumber);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
            this.invoicedata.invoice_date);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace('[[InvoiceServiceDetails]]',
            this.invoicedata.serviceDetails);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace('[[ConsumptionTax]]', this.invoicedata.consumptionTax);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total);
        JapanObject.invoiceDetail = JapanObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.JpnCurrencySymbol);

        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        JapanObject.appendix = JapanObject.appendix.replace('[[ProjectCode]]', this.invoicedata.Appendix[0]);
        JapanObject.appendix = JapanObject.appendix.replace('[[Title]]', this.invoicedata.Appendix[2]);
        JapanObject.appendix = JapanObject.appendix.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        JapanObject.appendix = JapanObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.JpnCurrencySymbol);
        }
        this.japanHtmlObject = JapanObject;

        // console.log(JapanObject);
        delete this.japanHtmlObject.maincontent;
        delete this.japanHtmlObject.headerCreate;
        delete this.japanHtmlObject.footerCreate;

        const obj: any = {};
        obj.pdf = this.originalInvoice;
        obj.saveObj = this.japanHtmlObject;

        console.log(obj);

        // this.common.createPdf(this.originalInvoice).subscribe(
        // (res) => {
        //     console.log(res);
        // }, (err) => console.log(err));

    }

    createIndiaInvoice(invoiceData) {
        this.indAddress = '';

        const IndiaInvoice: any = Object.assign({}, this.IndiaTemplate);
        IndiaInvoice.headerCreate = IndiaInvoice.headerCreate.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        IndiaInvoice.headerCreate = IndiaInvoice.headerCreate.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        IndiaInvoice.headerCreate = IndiaInvoice.headerCreate.replace('[[CurrencyName]]', this.invoicedata.IndCurrencyName);
        IndiaInvoice.headerCreate = IndiaInvoice.headerCreate.replace('[[CurrencySymbol]]', this.invoicedata.IndCurrencySymbol);

        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[PurchaseOrderNumber]]', this.invoicedata.purchaseOrderNumber);

        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Company]]', this.invoicedata.company);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[ClientContact]]', this.invoicedata.clientcontact1);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Address1]]', this.invoicedata.address1);
        IndiaInvoice.address2 = IndiaInvoice.address2.replace('[[Address2]]', this.invoicedata.address2);
        IndiaInvoice.address3 = IndiaInvoice.address3.replace('[[Address3]]', this.invoicedata.address3);
        IndiaInvoice.address4 = IndiaInvoice.address4.replace('[[Address4]]', this.invoicedata.address4);
        // IndiaInvoice.address5 = IndiaInvoice.address5.replace('[[Address5]]', this.invoicedata.indaddress5);
        // IndiaInvoice.address6 = IndiaInvoice.address6.replace('[[Address6]]', this.invoicedata.indaddress6);


        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Phone]]', this.invoicedata.phone);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Designation]]', this.invoicedata.designation);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Email]]', this.invoicedata.email);

        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
            this.invoicedata.invoice_date);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[InvoiceServiceDetails]]', this.invoicedata.serviceDetails);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.IndCurrencySymbol);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[CentralTax]]', this.invoicedata.centralTax);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[StateTax]]', this.invoicedata.stateTax);
        IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[Total]]', this.invoicedata.total);

        if (this.invoicedata.address2 != null && this.invoicedata.address2.trim() !== ''
         && this.invoicedata.address2 !== undefined) {
            this.indAddress = this.indAddress + IndiaInvoice.address2;
            console.log(this.indAddress);
        }
        if (this.invoicedata.address3 != null && this.invoicedata.address3.trim() !== ''
        && this.invoicedata.address3 !== undefined) {
            this.indAddress = this.indAddress + IndiaInvoice.address3;
            console.log(this.indAddress);
        }
        if (this.invoicedata.address4 != null && this.invoicedata.address4.trim() !== ''
        && this.invoicedata.address4 !== undefined) {
            this.indAddress = this.indAddress + IndiaInvoice.address4;
            console.log(this.indAddress);
        }
        // if (this.invoicedata.indaddress5 != null && this.invoicedata.indaddress5.trim() !== ''
        // && this.invoicedata.indaddress5 !== undefined) {
        //     this.indAddress = this.indAddress + IndiaInvoice.address5;
        //     console.log(this.indAddress);
        // }
        // if (this.invoicedata.indaddress6 != null && this.invoicedata.indaddress6.trim() !== ''
        // && this.invoicedata.indaddress6 !== undefined) {
        //     this.indAddress = this.indAddress + IndiaInvoice.address6;
        //     console.log(this.indAddress);
        // }
        if (this.indAddress !== null && this.indAddress.trim() !== '' && this.indAddress !== undefined) {
            IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[AddressMulti]]', this.indAddress);
            console.log(this.indAddress);
        } else {
            IndiaInvoice.maincontent = IndiaInvoice.maincontent.replace('[[AddressMulti]]', this.indAddress);
        }
        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        IndiaInvoice.appendixCreate = IndiaInvoice.appendixCreate.replace('[[ProjectCode]]', this.invoicedata.Appendix[0]);
        IndiaInvoice.appendixCreate = IndiaInvoice.appendixCreate.replace('[[Title]]', this.invoicedata.Appendix[1]);
        IndiaInvoice.appendixCreate = IndiaInvoice.appendixCreate.replace('[[ClientPOC]]', this.invoicedata.Appendix[2]);
        IndiaInvoice.appendixCreate = IndiaInvoice.appendixCreate.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        IndiaInvoice.appendixCreate = IndiaInvoice.appendixCreate.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.IndCurrencySymbol);
        }
        // this.IndiaTemplateCopy = IndiaInvoice;
        // console.log(IndiaInvoice.maincontent);

        let headerObj: any = this.headerstyle;
        headerObj = headerObj.replace('[[HeaderContent]]', IndiaInvoice.headerCreate);
        console.log('Header Html', headerObj);

        // const content = document.getElementById('main_content');
        let contentObj: string = this.contentStyle;
        let outerData: string = IndiaInvoice.maincontent;
        const appendix: string = IndiaInvoice.appendixCreate;
        if (!this.showAppendix) {
            outerData = IndiaInvoice.maincontent.replace('[[APPENDIX]]', '');
            contentObj = contentObj + outerData + '</body></html>';
        } else {
            outerData = IndiaInvoice.maincontent.replace('[[APPENDIX]]', appendix);
            contentObj = contentObj + outerData + '</body></html>';
            console.log('Main Content Html', contentObj);

        }


        const footer = document.getElementById('footer');
        let footerObj: any = this.footerStyle;
        footerObj = footerObj.replace('[[FooterContent]]', IndiaInvoice.footerCreate);
        console.log('Footer Html', footerObj);

        this.originalInvoice = {};
        this.originalInvoice.Header = headerObj;
        this.originalInvoice.Content = contentObj;
        this.originalInvoice.Footer = footerObj;

        console.log(headerObj);

        this.indAddress = '';
        const IndiaObject: any = Object.assign({}, this.IndiaTemplate);
        IndiaObject.header = IndiaObject.header.replace('[[InvoiceNumber]]', this.invoicedata.invoice_no);
        IndiaObject.header = IndiaObject.header.replace('[[InvoiceDate]]', this.invoicedata.invoice_date);
        IndiaObject.header = IndiaObject.header.replace('[[CurrencyName]]', this.invoicedata.IndCurrencyName);
        IndiaObject.header = IndiaObject.header.replace('[[CurrencySymbol]]', this.invoicedata.IndCurrencySymbol);

        IndiaObject.purchaseOrder = IndiaObject.purchaseOrder.replace('[[PurchaseOrderNumber]]',
            this.invoicedata.purchaseOrderNumber);

        IndiaObject.contactDetails1 = IndiaObject.contactDetails1.replace('[[Company]]', this.invoicedata.company);
        IndiaObject.contactDetails1 = IndiaObject.contactDetails1.replace('[[ClientContact]]',
            this.invoicedata.clientcontact1);
        IndiaObject.address = IndiaObject.address.replace('[[Address1]]', this.invoicedata.address1);
        IndiaObject.address2 = IndiaObject.address2.replace('[[Address2]]', this.invoicedata.address2);
        IndiaObject.address3 = IndiaObject.address3.replace('[[Address3]]', this.invoicedata.address3);
        IndiaObject.address4 = IndiaObject.address4.replace('[[Address4]]', this.invoicedata.address4);
        // IndiaObject.address5 = IndiaObject.address5.replace('[[Address5]]', this.invoicedata.indaddress5);
        // IndiaObject.address6 = IndiaObject.address6.replace('[[Address6]]', this.invoicedata.indaddress6);


        IndiaObject.contactDetails2 = IndiaObject.contactDetails2.replace('[[Phone]]', this.invoicedata.phone);
        IndiaObject.contactDetails2 = IndiaObject.contactDetails2.replace('[[Designation]]',
            this.invoicedata.designation);
        IndiaObject.contactDetails2 = IndiaObject.contactDetails2.replace('[[Email]]', this.invoicedata.email);

        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace(new RegExp('\\[\\[InvoiceDate\\]\\]', 'gi'),
            this.invoicedata.invoice_date);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace('[[InvoiceServiceDetails]]',
            this.invoicedata.serviceDetails);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.IndCurrencySymbol);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace('[[InvoiceFees]]', this.invoicedata.invoiceFees);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace('[[CentralTax]]', this.invoicedata.centralTax);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace('[[StateTax]]', this.invoicedata.stateTax);
        IndiaObject.invoiceDetail = IndiaObject.invoiceDetail.replace('[[Total]]', this.invoicedata.total);

        if (this.invoicedata.address2 != null && this.invoicedata.address2.trim() !== ''
            && this.invoicedata.address2 !== undefined) {
            this.indAddress = this.indAddress + IndiaObject.address2;
            console.log(this.indAddress);
        }
        if (this.invoicedata.address3 != null && this.invoicedata.address3.trim() !== ''
            && this.invoicedata.address3 !== undefined) {
            this.indAddress = this.indAddress + IndiaObject.address3;
            console.log(this.indAddress);
        }
        if (this.invoicedata.address4 != null && this.invoicedata.address4.trim() !== ''
            && this.invoicedata.address4 !== undefined) {
            this.indAddress = this.indAddress + IndiaObject.address4;
            console.log(this.indAddress);
        }
        // if (this.invoicedata.indaddress5 != null && this.invoicedata.indaddress5.trim() !== ''
        //     && this.invoicedata.indaddress5 !== undefined) {
        //     this.indAddress = this.indAddress + IndiaObject.address5;
        //     console.log(this.indAddress);
        // }
        // if (this.invoicedata.indaddress6 != null && this.invoicedata.indaddress6.trim() !== ''
        //     && this.invoicedata.indaddress6 !== undefined) {
        //     this.indAddress = this.indAddress + IndiaObject.address6;
        //     console.log(this.indAddress);
        // }
        if (this.indAddress !== null && this.indAddress.trim() !== '' && this.indAddress !== undefined) {
            IndiaObject.address = IndiaObject.address.replace('[[AddressMulti]]', this.indAddress);
            console.log(this.indAddress);
        } else {
            IndiaObject.address = IndiaObject.address.replace('[[AddressMulti]]', this.indAddress);
        }

        if (this.invoicedata.Appendix.length > 0) {
        this.showAppendix = true;
        IndiaObject.appendix = IndiaObject.appendix.replace('[[ProjectCode]]', this.invoicedata.Appendix[0]);
        IndiaObject.appendix = IndiaObject.appendix.replace('[[Title]]', this.invoicedata.Appendix[1]);
        IndiaObject.appendix = IndiaObject.appendix.replace('[[ClientPOC]]', this.invoicedata.Appendix[2]);
        IndiaObject.appendix = IndiaObject.appendix.replace('[[Amount]]', this.invoicedata.Appendix[3]);
        IndiaObject.appendix = IndiaObject.appendix.replace(new RegExp('\\[\\[CurrencySymbol\\]\\]', 'gi'),
            this.invoicedata.IndCurrencySymbol);
        }

        this.indiaHtmlObject = IndiaObject;

        delete this.indiaHtmlObject.maincontent;
        delete this.indiaHtmlObject.headerCreate;
        delete this.indiaHtmlObject.footerCreate;
        delete this.indiaHtmlObject.address2;
        delete this.indiaHtmlObject.address3;
        delete this.indiaHtmlObject.address4;
        delete this.indiaHtmlObject.address5;
        delete this.indiaHtmlObject.address6;



        const obj: any = {};
        obj.pdf = this.originalInvoice;
        obj.saveObj = this.indiaHtmlObject;

        console.log(obj);

        // this.common.createPdf(this.originalInvoice).subscribe(
        // (res) => {
        //     console.log(res);
        // }, (err) => console.log(err));


    }

    getData(data: { htmldata: string; class: string; }) {
        console.log(data);
        this.editor = false;
        const mainUl = document.getElementById(this.elementId);
        const getLi = mainUl.getElementsByTagName('li')[1];
        console.log(data.htmldata);
        if (this.elementId === 'appendix') {
            document.getElementById(this.elementId).innerHTML = data.htmldata.replace(/&nbsp;/g, '');
        } else if (getLi === null || getLi === undefined) {
            document.getElementById(this.elementId).innerHTML = data.htmldata;
        } else {
            getLi.firstElementChild.innerHTML = data.htmldata;
        }
        document.getElementById('appendix').className = data.class;
    }

    confirm() {
        const inner = document.getElementById('main_content');
        const buttons = inner.getElementsByTagName('p-button');
        // console.log(buttons);
        if (buttons.length > 0) {
            buttons[0].remove();
            if (this.showAppendix) {
            buttons[1].remove();
            buttons[0].remove();
            } else {
            buttons[0].remove();
            }
        }

        if (document.querySelector('.col10') !== null) {
            const el = document.querySelector('.col10');
            el.innerHTML = el.innerHTML.replace(/&nbsp;/g, '');
        }

        const header = document.getElementById('header');
        let headerObj: any = this.headerstyle;
        headerObj = headerObj.replace('[[HeaderContent]]', header.outerHTML);
        // console.log('Header Html', headerObj);

        const content = document.getElementById('main_content');
        let contentObj: string = this.contentStyle;
        const outerData: string = content.outerHTML;
        contentObj = contentObj + outerData + '</body></html>';
        // console.log('Main Content Html', contentObj);


        const footer = document.getElementById('footer');
        let footerObj: any = this.footerStyle;
        footerObj = footerObj.replace('[[FooterContent]]', footer.outerHTML);
        // console.log('Footer Html', footerObj);

        this.modifiedInvoice = {};

        this.modifiedInvoice.header = headerObj;
        this.modifiedInvoice.content = contentObj;
        this.modifiedInvoice.footer = footerObj;

        console.log(this.modifiedInvoice);

        const obj: any = {};
        obj.pdf = this.modifiedInvoice;
        if (Object.keys(this.USHtmlObject).length > 0) {
            this.USHtmlObject.header = document.getElementById('header').innerHTML;
            this.USHtmlObject.footer = document.getElementById('footer').innerHTML;
            this.USHtmlObject.contactDetails = document.getElementById('contactDetails1').innerHTML;
            this.USHtmlObject.contactDetails2 = document.getElementById('contactDetails2').innerHTML;
            this.USHtmlObject.purchaseOrder = document.getElementById('purchaseOrderDetails').innerHTML;
            this.USHtmlObject.invoiceDetail = document.getElementById('invoiceDetails').innerHTML;
            this.USHtmlObject.paymentInstructions = document.getElementById('paymentInstructions').innerHTML;
            this.USHtmlObject.paymentDetails = document.getElementById('paymentDetails').innerHTML;
            if (this.showAppendix) {
            this.USHtmlObject.appendix = document.getElementById('appendix').innerHTML;
            }
            obj.saveObj = this.USHtmlObject;
        } else if (Object.keys(this.japanHtmlObject).length > 0) {
            this.japanHtmlObject.header = document.getElementById('header').innerHTML;
            this.japanHtmlObject.footer = document.getElementById('footer').innerHTML;
            this.japanHtmlObject.contactDetails = document.getElementById('contactDetails').innerHTML;
            this.japanHtmlObject.purchaseOrder = document.getElementById('purchaseOrderDetails').innerHTML;
            this.japanHtmlObject.invoiceDetail = document.getElementById('invoiceDetails').innerHTML;
            this.japanHtmlObject.paymentInstructions = document.getElementById('paymentInstructions1').innerHTML;
            this.japanHtmlObject.paymentDetails = document.getElementById('paymentInstructions2').innerHTML;
            this.japanHtmlObject.appendix = document.getElementById('appendix').innerHTML;
            obj.saveObj = this.japanHtmlObject;
        } else if (Object.keys(this.indiaHtmlObject).length > 0) {
            this.indiaHtmlObject.header = document.getElementById('header').innerHTML;
            this.indiaHtmlObject.footer = document.getElementById('footer').innerHTML;
            this.indiaHtmlObject.contactDetails1 = document.getElementById('contactDetails1').innerHTML;
            this.indiaHtmlObject.contactDetails2 = document.getElementById('contactDetails2').innerHTML;
            this.indiaHtmlObject.address = document.getElementById('address').innerHTML;
            this.indiaHtmlObject.purchaseOrder = document.getElementById('purchaseOrderDetails').innerHTML;
            this.indiaHtmlObject.invoiceDetail = document.getElementById('invoiceDetails').innerHTML;
            this.indiaHtmlObject.paymentInstructions = document.getElementById('paymentInstructions1').innerHTML;
            this.indiaHtmlObject.paymentDetails = document.getElementById('paymentInstructions2').innerHTML;
            this.indiaHtmlObject.appendix = document.getElementById('appendix').innerHTML;
            obj.saveObj = this.indiaHtmlObject;
        }

        console.log(obj);
        // this.common.saveData(contentObj).subscribe((res) => {
        //     console.log(res);
        // });
    }
}
  // savePdf() {
  //   var data = document.getElementById('contentToConvert');
  //   html2canvas(data).then(canvas => {
  //     var imgWidth = 210;
  //     var pageHeight = 295;
  //     var imgHeight = 300;
  //     var heightLeft = imgHeight;

  //     const contentDataURL = canvas.toDataURL('image/png');
  //     let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
  //     var position = 0;
  //     var options = {
  //       pagesplit: true
  //     };
  //     pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight , options);
  //     pdf.save('invoice.pdf'); // Generated PDF;
  //   });
  // }
